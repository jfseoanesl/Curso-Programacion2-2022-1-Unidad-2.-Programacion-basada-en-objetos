package vista;

import modelo.*;
import java.util.*;

public class PruebaRectangulo {
    
    public static void main(String[] args) {
        
        double base, altura;
        String color;
        
        Scanner entrada = new Scanner(System.in);
        System.out.print("Base 1: ");
        base = entrada.nextDouble();
        System.out.print("Altura 1: ");
        altura = entrada.nextDouble();
        System.out.print("Color: ");
        color = entrada.next();
        
        Rectangulo.color = color;
        
        Rectangulo r = new Rectangulo();
        r.setAltura(altura);
        r.setBase(base);
       
        imprimirRectangulo(r);
        
        System.out.println("---------------------");
        
        Rectangulo r2 = new Rectangulo();
        r2.setBase(20);
        r2.setAltura(30);
        imprimirRectangulo(r2);
        
        
        
    }
    
    
    public static void imprimirRectangulo(Rectangulo r){
        System.out.println("Base inicial: " + r.getBase());
        System.out.println("Altura inicial: " + r.getAltura());
        System.out.println("Color: " + Rectangulo.color);
        System.out.println("Area: " + r.calcularArea());
        System.out.println("Perimetro: " + r.calcularPerimetro());
    }
}
