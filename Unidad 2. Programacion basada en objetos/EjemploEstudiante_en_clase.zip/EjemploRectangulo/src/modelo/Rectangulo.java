package modelo;

public class Rectangulo {
    
    // ATRIBUTOS DE INSTANCIA 
    private double base;
    private double altura;
    
    // ATRIBUTO DE CLASE
    public static String color="Negro";
    
    //METODO CONSTRUCTOR
    public Rectangulo(){
        this.base  = 10;
        this.altura=20;
        
    }
    
    // METODOS GETTER
    public double getBase(){
        return this.base;
    }
    
    public double getAltura(){
        return this.altura;
    }
    
    //METODOS SETTER
    public void setBase(double base){
        this.base = base;
    }
    
    public void setAltura(double altura){
        this.altura = altura;
    }
    
    // METODOS MIEMBROS
    public double calcularArea(){
        double area = this.base * this.altura;
        return area;
    }
    
    public double calcularPerimetro(){
        return 2 * this.base + 2 * this.altura;
    }
    
    
    
    
    
}

