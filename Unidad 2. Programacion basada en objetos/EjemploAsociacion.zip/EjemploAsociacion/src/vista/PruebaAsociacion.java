package vista;

import modelo.*;

public class PruebaAsociacion {
    
    public static void main(String[] args) {
        
        Segmento ab = new Segmento();
        System.out.println("Longitud Segmento AB: " + ab.longitudSegmento());
        
        System.out.println("-------------------------");
        
        Punto c = new Punto();
        Punto d = new Punto(10,10);
        Segmento cd = new Segmento(c,d);
        System.out.println("Longitud Segmento CD : " + cd.longitudSegmento());
        
    }
    
}
