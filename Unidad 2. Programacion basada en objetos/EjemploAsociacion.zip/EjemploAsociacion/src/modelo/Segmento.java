package modelo;

public class Segmento {
    private Punto inicio;
    private Punto fin;

    public Segmento(Punto inicio, Punto fin) {
        this.inicio = inicio;
        this.fin = fin;
    }

    public Segmento() {
        this.inicio = new Punto();
        this.fin= new Punto();
    }

    /**
     * @return the inicio
     */
    public Punto getInicio() {
        return inicio;
    }

    /**
     * @param inicio the inicio to set
     */
    public void setInicio(Punto inicio) {
        this.inicio = inicio;
    }

    /**
     * @return the fin
     */
    public Punto getFin() {
        return fin;
    }

    /**
     * @param fin the fin to set
     */
    public void setFin(Punto fin) {
        this.fin = fin;
    }
    
    public double longitudSegmento(){
        double dx = this.inicio.getX() - this.fin.getX();
        double dy = this.inicio.getY() - this.fin.getY();
        
        double dx2 = Math.pow(dx, 2);
        double dy2 = Math.pow(dy, 2);
        
        return Math.sqrt(dx2+dy2);
    }
    
}
