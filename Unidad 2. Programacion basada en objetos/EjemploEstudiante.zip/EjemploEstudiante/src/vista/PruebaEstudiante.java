package vista;
import modelo.*;

public class PruebaEstudiante {
    
    public static void main(String[] args) {
        
        Estudiante a, b, c;
        
        a = new Estudiante();
        imprimirEstudiante(a);
        
        b= new Estudiante();
        b.setNota1(3);
        b.setNota2(4);
        b.setNota3(5);
        imprimirEstudiante(b);
        
        c = new Estudiante();
        c.setNota1(4);
        c.setNota2(3);
        c.setNota3(1);
        imprimirEstudiante(c);
        
        
        
    }
    
    public static void imprimirEstudiante(Estudiante e){
        System.out.println("Nota 1: " + e.getNota1());
        System.out.println("Nota 2: " + e.getNota2());
        System.out.println("Nota 3: " + e.getNota3());
        System.out.println("Definitiva: " + e.calcularDefinitiva());
        System.out.println("---------------------------------------------");
    }
    
}
