package modelo;

public class Grupo {

    private int id;
    private String noGrupo;
    private int noEstudiantes;
    private Docente docente; // debido a la relacion de agregacion

    public Grupo() {
    }

    public Grupo(int id, String noGrupo, int noEstudiantes) {
        this.id = id;
        this.noGrupo = noGrupo;
        this.noEstudiantes = noEstudiantes;

    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the noGrupo
     */
    public String getNoGrupo() {
        return noGrupo;
    }

    /**
     * @param noGrupo the noGrupo to set
     */
    public void setNoGrupo(String noGrupo) {
        this.noGrupo = noGrupo;
    }

    /**
     * @return the noEstudiantes
     */
    public int getNoEstudiantes() {
        return noEstudiantes;
    }

    /**
     * @param noEstudiantes the noEstudiantes to set
     */
    public void setNoEstudiantes(int noEstudiantes) {
        this.noEstudiantes = noEstudiantes;
    }

    /**
     * @return the docente
     */
    public Docente getDocente() {
        return docente;
    }

    /**
     * @param docente the docente to set
     */
    public void setDocente(Docente docente) {
        this.docente = docente;
        this.docente.adicionarNuevoGrupo(this);
    }

    @Override
    public String toString() {
        return "{id=" + id + 
               ", noGrupo=" + noGrupo + 
               ", noEstudiantes="+ noEstudiantes +
               ", Docente: " + this.docente.getNombre() +
               " " + this.docente.getApellido()+'}' ;
    }

}
