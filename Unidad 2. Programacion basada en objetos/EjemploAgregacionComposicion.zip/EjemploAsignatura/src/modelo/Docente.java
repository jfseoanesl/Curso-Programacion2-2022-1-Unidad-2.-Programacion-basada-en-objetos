package modelo;

public class Docente {
    private String cc;
    private String nombre;
    private String apellido;
    
    private Grupo grupos[]; // por la navegabilidad de la asociacion
    private static final int NO_MAX_GRUPOS = 5;
    private int noGruposAsignados;

    public Docente() {
    }

    public Docente(String cc, String nombre, String apellido) {
        this.cc = cc;
        this.nombre = nombre;
        this.apellido = apellido;
        this.noGruposAsignados=0;
        this.grupos = new Grupo[Docente.NO_MAX_GRUPOS];
    }

    /**
     * @return the cc
     */
    public String getCc() {
        return cc;
    }

    /**
     * @param cc the cc to set
     */
    public void setCc(String cc) {
        this.cc = cc;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the apellido
     */
    public String getApellido() {
        return apellido;
    }

    /**
     * @param apellido the apellido to set
     */
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    @Override
    public String toString() {
        return "Docente{" + "cc=" + cc + 
                ", nombre=" + nombre + 
                ", apellido=" + apellido + "}\n" + 
                "Grupos a su cargo:\n" +  
                 this.getStringGrupos();
    }
    
    public void adicionarNuevoGrupo(Grupo g){
        this.grupos[this.noGruposAsignados]=g;
        this.noGruposAsignados++;
    }
    
    public boolean tieneCupo(){
        return this.noGruposAsignados<Docente.NO_MAX_GRUPOS;
    }
    
    private String getStringGrupos(){
        String grupos="";
        for(int i=0;i<this.noGruposAsignados;i++){
            grupos = grupos + '{' + 
                    this.grupos[i].getNoGrupo() + 
                    ", " + this.grupos[i].getNoEstudiantes() + " Estudiantes }";
        }
        return grupos;
    }
    
}
