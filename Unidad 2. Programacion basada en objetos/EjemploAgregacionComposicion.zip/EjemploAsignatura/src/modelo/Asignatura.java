package modelo;


public class Asignatura {
    private String codigo;
    private String nombre;
    private int noCreditos;
    
    // atributo definido por la relacion de composicion
    private Grupo grupos[];  
    private static final int NO_MAX_GRUPOS = 3;
    private int noGruposCreados;

    public Asignatura(String codigo, String nombre, int noCreditos) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.noCreditos = noCreditos;
        this.grupos = new Grupo[Asignatura.NO_MAX_GRUPOS];
        this.noGruposCreados = 0;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getNoCreditos() {
        return noCreditos;
    }

    public void setNoCreditos(int noCreditos) {
        this.noCreditos = noCreditos;
    }

    public Grupo[] getGrupos() {
        return grupos;
    }

    public int getNoGruposCreados() {
        return noGruposCreados;
    }

    public void setNoGruposCreados(int noGruposCreados) {
        this.noGruposCreados = noGruposCreados;
    }
    
    //Crea un nuevo grupo y lo agrega a los grupos de la asignatura
    // return true (en caso de que se agrege el grupo correctemente) o
    // return false en caso contrario
    public boolean crearNewGrupo(int id, String noGrupo, int nEstudiante){
        if(this.noGruposCreados<Asignatura.NO_MAX_GRUPOS){
            Grupo g = new Grupo(id, noGrupo, nEstudiante);
            this.grupos[this.noGruposCreados]=g;
            this.noGruposCreados++;
            return true;
        }
        return false;
    }
    
    //Busca un grupo por su Id y le agrega el docente asignado
    //return true (si se agrega correctamente el docente) o
    //return false en caso contrario
    public boolean asignarDocenteGrupo(int idGrupo, Docente docente){
        Grupo grupoEncontrado = null;
        for(int i=0; i<this.noGruposCreados;i++){
            if(idGrupo==this.grupos[i].getId()){
                grupoEncontrado=this.grupos[i];
                break;
            }
        }
        if(grupoEncontrado==null || docente==null || !docente.tieneCupo())
            return false;
        
        grupoEncontrado.setDocente(docente);
        return true;
    }

    @Override
    public String toString() {
        return "Asignatura{" + "codigo=" + codigo + 
                ", nombre=" + nombre + 
                ", noCreditos=" + noCreditos + "}\n" + 
                "Grupos registrados:\n" + this.getStringGrupos();
    }
    
    private String getStringGrupos(){
        String grupos="";
        for(int i=0; i<this.noGruposCreados; i++){
            grupos = grupos + this.grupos[i].toString()+"\n";
        }
        return grupos;
    }
    
    
}
