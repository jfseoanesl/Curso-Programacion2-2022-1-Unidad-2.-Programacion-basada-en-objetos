package vista;

import modelo.*;

public class PruebaAsignatura {
    public static void main(String[] args) {
        
        Docente jairo = new Docente("77", "Jairo", "Seoanes");
        
        Asignatura poo = new Asignatura("SS300", "Programacion II", 3);
        poo.crearNewGrupo(1, "G01", 15);
        poo.asignarDocenteGrupo(1, jairo);
        
        poo.crearNewGrupo(2, "G02", 20);
        poo.asignarDocenteGrupo(2, jairo);     
        
        System.out.println(poo);
        System.out.println(jairo);
        
    }
}
